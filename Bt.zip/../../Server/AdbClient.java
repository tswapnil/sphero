import java.io.*;
import java.net.*;
import java.util.*;

/**
* Initialize connection to the phone
*
**/
public class AdbClient {

private static Socket socket;
private static Scanner sc;
private static PrintWriter out;

public static void main(String[] args){

initializeConnection();


}

public static void initializeConnection(){
//Create socket connection
try{
//localhost
//
socket = new Socket("localhost", 34355);
System.out.println("Got Socket ..... ");

out = new PrintWriter(socket.getOutputStream(), true);
//in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
sc=new Scanner(socket.getInputStream());
BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
String inputLine = null;

while( !((inputLine = br.readLine()).equalsIgnoreCase("Bye"))){
  out.println(inputLine);

}


// add a shutdown hook to close the socket if system crashes or exists unexpectedly
Thread closeSocketOnShutdown = new Thread() {
public void run() {
try {
socket.close();
} catch (IOException e) {
e.printStackTrace();
}
}
};
Runtime.getRuntime().addShutdownHook(closeSocketOnShutdown);
} catch (UnknownHostException e) {
System.out.println("Socket connection problem (Unknown host)"+e.getStackTrace());
} catch (IOException e) {
 System.out.println("Could not initialize I/O on socket "+e.getStackTrace());
}
}

}
